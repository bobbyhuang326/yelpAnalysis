hdfs dfs -rm -r -f Q1
hdfs dfs -rm -r -f Q2
hdfs dfs -rm -r -f Q3
hdfs dfs -rm -r -f Q4
hdfs dfs -rm -r -f Q5